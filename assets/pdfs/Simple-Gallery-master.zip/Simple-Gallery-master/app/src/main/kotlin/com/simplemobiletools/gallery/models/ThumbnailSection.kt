package com.simplemobiletools.gallery.models

data class ThumbnailSection(val title: String) : ThumbnailItem()
