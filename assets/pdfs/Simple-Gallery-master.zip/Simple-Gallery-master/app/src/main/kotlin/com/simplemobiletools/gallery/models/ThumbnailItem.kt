package com.simplemobiletools.gallery.models

open class ThumbnailItem
