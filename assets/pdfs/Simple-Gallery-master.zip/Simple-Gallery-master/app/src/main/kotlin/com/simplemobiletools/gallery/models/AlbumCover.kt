package com.simplemobiletools.gallery.models

data class AlbumCover(val path: String, val tmb: String)
