package RoundTwo.ArraysAndStrings;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StringsPractTest {

    @Test
    void isUnique() {
        String testTrue = "abcde"; // true
        String testFalse = "abaa"; // false

        assertTrue(StringsPract.isUnique(testTrue));
        assertFalse(StringsPract.isUnique(testFalse));
    }

    @Test
    void checkPermutation() {
        String str1 = "abcd";
        String str2 = "abdc";
        String str3 = "ab";
        String str4 = " aa";
        String str5 = "aa ";

        assertTrue(StringsPract.checkPermutation(str1, str2));
        assertTrue(StringsPract.checkPermutation(str4, str5));
        assertFalse(StringsPract.checkPermutation(str3, str4));
    }

    @Test
    void urlify() {
        String input1 = "Mr John Smith    ";
        int input1Length = 13;

        assertEquals("Mr%20John%20Smith", StringsPract.urlify(input1, input1Length));
    }

    @Test
    void isPalinPerm() {
        String inputTrue = "Tact coa";
        String inputFalse = "Tact coaa";
        String inputSpecial = "aaba";

        assertTrue(StringsPract.isPalinPerm(inputTrue));
        assertFalse(StringsPract.isPalinPerm(inputFalse));
        assertFalse(StringsPract.isPalinPerm(inputSpecial));

        inputSpecial = "abaaa";
        assertTrue(StringsPract.isPalinPerm(inputSpecial));

        assertTrue(StringsPract.isPalinPerm(" "));
        assertTrue(StringsPract.isPalinPerm("     "));
        assertTrue(StringsPract.isPalinPerm(" a"));

    }

    @Test
    void isOneEditAway() {
        String input1 = "pale";
        String input2 = "ple";

        assertTrue(StringsPract.isOneEditAway(input1,input2));

        input1 = "pales";
        input2 = "pale";
        assertTrue(StringsPract.isOneEditAway(input1,input2));

        input1 = "pale";
        input2 = "bale";
        assertTrue(StringsPract.isOneEditAway(input1,input2));

        input1 = "pale";
        input2 = "bake";
        assertFalse(StringsPract.isOneEditAway(input1,input2));

        input1 = "pale";
        input2 = "pakea";
        assertFalse(StringsPract.isOneEditAway(input1,input2));

        input1 = "pal";
        input2 = "pakea";
        assertFalse(StringsPract.isOneEditAway(input1,input2));

        input1 = "pppp";
        input2 = "appb";
        assertFalse(StringsPract.isOneEditAway(input1,input2));

        input1 = "pppp";
        input2 = "pppb";
        assertTrue(StringsPract.isOneEditAway(input1,input2));
    }

    @Test
    void compressString() {
        String input = "aabcccccaaab";
        String output = "a2b1c5a3b1";
        assertEquals(output,StringsPract.compressString(input));

        input = "aaaa";
        output = "a4";
        assertEquals(output,StringsPract.compressString(input));

        input = "a";
        output = "a";
        assertEquals(output,StringsPract.compressString(input));

        input = "aacc";
        output = "a2c2";
        assertEquals(output,StringsPract.compressString(input));

        input = "acbcc";
        output = "acbcc";
        assertEquals(output,StringsPract.compressString(input));

    }
}