package RoundTwo.ArraysAndStrings;

import java.util.BitSet;
import java.util.HashMap;
import java.util.Map;

public class StringsPract {
    public static boolean isUnique(String str) {
        if (str == null) return false;
        if (str.length() == 1) return true;

        BitSet bitSet = new BitSet(26);

        for (int i = 0; i < str.length(); ++i) {
            if (bitSet.get(str.charAt(i) - 'a'))
                return false;
            else
                bitSet.set(str.charAt(i) - 'a');
        }
        return true;
    }

    public static boolean checkPermutation(String str1, String str2) {
        if (str1 == null || str2 == null) return false;
        if (str1.equals(str2)) return true;
        if (str1.length() != str2.length()) return false;

        int sumStr1 = 0;
        int sumStr2 = 0;

        for (int i = 0; i < str1.length(); ++i) {
            sumStr1 += str1.charAt(i) - '0';
        }

        for (int j = 0; j < str2.length(); ++j) {
            sumStr2 += str2.charAt(j) - '0';
        }

        return sumStr1 == sumStr2;
    }

    public static String urlify(String str, int len) {
        if (str == null) return null;
        if (str.length() < 4) return null;

        String ify = "02%";
        char[] cArray = str.toCharArray();

        int chIndex = str.length() - 1;
        int swapIndex = len - 1;
        while (chIndex >= 0) {
            if (cArray[swapIndex] == ' ') {
                for (int i = 0; i < ify.length(); ++i) {
                    cArray[chIndex] = ify.charAt(i);
                    --chIndex;
                }
                ++chIndex;
            } else {
                cArray[chIndex] = cArray[swapIndex];
            }

            --swapIndex;
            --chIndex;
        }

        return String.valueOf(cArray);
    }

    public static boolean isPalinPerm(String str) {
        if (str == null) return false;
        if (str.length() == 1) return true;

        str = str.trim().toLowerCase(); //strips whitespace

        HashMap<Character, Integer> map = new HashMap<>();

        for (int i = 0; i < str.length(); ++i) {
            char c = str.charAt(i);
            if (c != ' ') {
                if (map.containsKey(c)) {
                    map.put(c, map.get(c) + 1);
                } else {
                    map.put(c, 1);
                }
            }

        }

        int oddCount = 0;
        int evenCount = 0;

        for (Map.Entry entry : map.entrySet()) {
            if ((int) entry.getValue() % 2 == 1) {
                ++oddCount;
            } else {
                ++evenCount;
            }
        }

        //Special cases. When all elements are the same. Or when we have evenCount == 0, we look at map.size
        if (evenCount == 0) {
            if (map.size() > 1) {
                return false;
            } else if (oddCount > 0) {
                return true;
            }
        }
        return oddCount < 2;
    }

    public static boolean isOneEditAway(String str1, String str2) {
        if (str1 == null || str2 == null) return false;
        if (str1.length() == 1 && str2.length() == 1) return true;

        if (Math.abs(str1.length() - str2.length()) > 1) return false;

        int editCount = 0;
        if (str1.length() == str2.length()) {
            for (int i = 0; i < str1.length(); ++i) {
                if (str1.charAt(i) != str2.charAt(i)) {
                    ++editCount;
                }
                if (editCount > 1) return false;
            }
        } else {
            String smallerStr = str1.length() < str2.length() ? str1 : str2;
            int smallerIndex = smallerStr.length();
            String longerStr = str1.length() > str2.length() ? str1 : str2;
            int longerIndex = 0;
            for (int i = 0; i < smallerIndex; ++i) {
                if (longerStr.charAt(longerIndex) != smallerStr.charAt(i)) {
                    ++editCount;
                    --i;
                }
                if (editCount > 1) {
                    return false;
                }
                ++longerIndex;
            }
        }
        return true;
    }

    public static String compressString(String str) {
        if (str == null) return null;
        if (str.length() < 3) return str;

        char lastChar = str.charAt(0);
        int charCount = 0;

        StringBuilder stringBuilder = new StringBuilder();

        for (int i = 0; i < str.length(); ++i) {

            char c = str.charAt(i);
            if (c == lastChar) {
                ++charCount;
            } else {
                stringBuilder.append(lastChar);
                stringBuilder.append(charCount);
                System.out.println(stringBuilder.toString());
                lastChar = c;
                charCount = 1;
            }
            if (stringBuilder.length() + 2 > str.length()) return str;
        }

        stringBuilder.append(str.charAt(str.length() - 1));
        stringBuilder.append(charCount);

        return stringBuilder.toString();
    }
}
