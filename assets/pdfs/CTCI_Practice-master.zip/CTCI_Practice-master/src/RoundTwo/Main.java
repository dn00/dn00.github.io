package RoundTwo;

import RoundTwo.ArraysAndStrings.StringsPract;

public class Main {
    public static void main(String[] args) {
//        String testString1 = "abcdefg"; // returns true
//        String testString2 = "abade"; // returns false
//
//        System.out.println(StringsPract.isUnique(testString1));
//        System.out.println(StringsPract.isUnique(testString2));
    }
}
