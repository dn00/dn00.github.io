package com.company.LinkedList;

import java.util.Stack;

import static com.company.QuickPrintString.printt;
import static com.company.QuickPrintString.printtln;

public class LinkedList {
    public static class Node {
        Node next = null;
        int data;

        public Node(int d) {
            data = d;
        }
        public Node() {
        }
        public void setNext(Node n) {
            next = n;
        }
    }

    Node head = null;

    public LinkedList(Node n) {
        head = n;
    }

    public LinkedList(int d) {
        head = new Node(d);
    }

    public Node getHead() {
        return head;
    }
    public Node getHeadNext() {
        return head.next;
    }

    public void appendToTail(int d) {
        Node end = new Node(d);
        Node n = getHead();
        while (n.next != null) {
            n = n.next;
        }
        n.next = end;
    }
    public void appendToTail(Node node) {
        Node n = getHead();
        while (n.next != null) {
            n = n.next;
        }
        n.next = node;
    }

    public void printLinkedList() {
        Node n = head;
        while(n != null) {
            printt(n.data + " -> ");
            n = n.next;
        }
    }

    public Node deleteAnyMiddleNode(Node delNode, Node n) {
        if (n.next == null || delNode.next == null) {
            return null;
        }
        if (n.next == delNode) {
//            printtln("delNode: " + delNode.data);
//            printtln("delNodeNext: " + delNode.next.data);
//            printtln("n: " + n.data);
            n.next = delNode.next;
//            printtln("new n: " + n.data);

        }

        return deleteAnyMiddleNode(delNode, n.next);
    }

    /** recursively find the length of a list*/
    public int findLength(int l, Node n) {
        if (n == null) {
            return l;
        }
        return findLength(++l, n.next);
    }

    /** Recursively finds the kth to last element in a list
     *  todo create another method that does this with the same return value
     * */
    public Node findkthToLastElement(int k, Node n) {
        if (n == head) {
            k = findLength(0, n) - k;
        }
        if (n == null || k == 0) {
            printtln("\n" + n.data);
            return n;
        }
        return findkthToLastElement(--k, n.next);
    }

    /** Find nth to last element without finding length
     * */

    public int nthToLastElement(int k, Node n) {
        printtln("startend: " );

        if (n == null) {
            return 0;
        }
        printtln("ndata: " + n.data);

        int index = nthToLastElement(k, n.next) + 1;
        printtln("index: " + index);

        if (index == k) {
            printtln("n: " + n.data);
        }
        return index;
    }


    /** Removes duplicates by doing multiple passes
     * todo multiple of the same elements doesn't get removed
     * * */
    public void removeDuplicates() {
        Node n = head;
        Node prev;
        Node n2;
        while (n != null) {
            prev = n;
            n2 = n.next;
            while(n2 != null) {
                if (n.data == n2.data) {
                    prev.next = n2.next;
                    n2 = prev.next;
                } else {
                    prev = n2;
                    n2 = n2.next;
                }
            }
            n = n.next;
        }
    }

    /** Adds two numbers represented by linked lists in reverse order of the same length*/
    public LinkedList addTwoNumbers(Node n2) {
        Node newNumber = new Node(0);
        Node n1 = head;
        LinkedList sumList = new LinkedList(newNumber);

        int carry = 0;
        int add;
        while (n1 != null && n2 != null) {
            add = n1.data + n2.data + carry;

            if (add > 9) {
                carry = add / 10;
                add = add - 10;
            } else {
                carry = 0;
            }
            // printtln("Sum: " + add);
            // printtln("carry: " + carry);

            if (n1.next == null || n2.next == null) {
                newNumber.data = add + carry;
                break;
            } else
                newNumber.data = add;


            newNumber.next = new Node();
            newNumber = newNumber.next;

            n1 = n1.next;
            n2 = n2.next;
        }
        return sumList;
    }

    /** Recursively add two linkedlists in forward order of same length in place*/
    public int addTwoNumbersForwardOrder(Node n2, Node n1) {
        if (n2 == null) {
            return 0;
        }

        int add = addTwoNumbersForwardOrder(n2.next, n1.next) + n2.data + n1.data;

//        printtln("add: " + add);
        if (n1 == head) {
            n1.data = add;
        }
         else if (add > 9) {
            n1.data = (add - 10) ;
        } else {
            n1.data = add;
        }

        return (add / 10);

    }
//    /** Recursively determines if a linkedlist is a palindrome*/
//    public boolean isPalindrome(Node n, Node dummyNode) {
//        if (n.next == null) {
//            if (n.data == dummyNode.data)
//                return true;
//            else
//                return false;
//        }
//
//        boolean b = isPalindrome(n.next, dummyNode);
//
//        printtln("ndata: " + n.data + "Dummy: " + dummyNode.data);
//
//        if (n.data == dummyNode.data) {
//            dummyNode = dummyNode.next;
//            printtln("true");
//        }
//
//
//        return false;
//
//    }

    public boolean isPalindromeWithStack() {
        Node n = getHead();

        Stack<Integer> stack = new Stack<>();

        int length = 0;
        while (n != null) {
            ++length;
            stack.push(n.data);
            n = n.next;
        }

        n = getHead();

        for (int i = 0; i < length / 2; ++i) {
            if (n.data != stack.pop())
                return false;

            n = n.next;
        }

        stack.clear();
        return true;
    }

    public Node findIntersectNode(Node n1, Node n2) {
        Node n1DummyHead = n1;
        Node n2DummyHead = n2;
        int lengthDifference = 0;
        boolean n2endReached = false, n1endReached = false;
        boolean n1ReachedEndFirst = false;

        while (true) {
            printtln("endReached: " + n1endReached + n1 + "n1: " + n1.data + " n2: " + n2.data);
            if (n1.next != null) {
                n1 = n1.next;
            } else {
                if (n2endReached && n1endReached) {
                    break;
                }
                n1endReached = true;
            }
            if (n2.next != null) {
                n2 = n2.next;
            } else {
                if (n2endReached && n1endReached) {
                    break;
                }
                n2endReached = true;
            }


            if (n1endReached || n2endReached) {
                if (n1endReached && !n2endReached) {
                    n1ReachedEndFirst = true;
                }

                ++lengthDifference;
            }
        }

        n1 = n1DummyHead;
        n2 = n2DummyHead;

        //bug fix
        if (n1ReachedEndFirst) {
            --lengthDifference;
        }

        while (n1 != null && n2 != null) {
//            printtln("" + n1.data + " n2: " + n2.data);
            if (lengthDifference > 0) {
                if (n1ReachedEndFirst) {
                    n2 = n2.next;

                } else {
                    n1 = n1.next;
                }
                --lengthDifference;
            } else {
                if (n1 == n2) {
                    printtln("Found intersecting node - n1: " + n1.data + " n2: " + n2.data);
                    return n1;
                }
                n1 = n1.next;
                n2 = n2.next;
            }

        }
        return null;
    }
    /**
     * Detects a loop in a corrupted linkedlist where an element points
     * back to a previous element. Returns start of loop.
     * We use runner method here where p2 iterates 2n of p1.
     *
     * */
    public Node loopDetection() {
        Node p1 = head;
        Node p2 = head;

        while (true) {
            printtln("p1: " + p1.data + "p2: " + p2.data);
            p1 = p1.next;
            p2 = p2.next.next;
            if (p1 == p2) {
                printtln("Found loop: " + p1.data);
                break;
            }
        }
        while (true) {
            p1 = p1.next;
            p2 = p2.next;
            if (p1 == p2) {
                printtln("Found start of loop: " + p1.data);
                return p1;
            }
        }
    }

    public static Node mergeTwoLists(Node l1, Node l2){
        if(l1 == null) return l2;
        if(l2 == null) return l1;
        if(l1.data < l2.data){
            l1.next = mergeTwoLists(l1.next, l2);
            return l1;
        } else{
            l2.next = mergeTwoLists(l1, l2.next);
            return l2;
        }
    }

    public static void printList(Node l) {
        while (l != null) {
            printtln("list: " + l.data);
            l = l.next;
        }
    }
}
