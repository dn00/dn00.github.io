package com.company;

public class QuickPrintString {
    public static void printt(String s) {
        System.out.print(s);
    }

    public static void printtln(String s) {
        System.out.println(s);
    }
    public static void printtln(boolean s) {
        System.out.println(s);
    }
    public static void printtln(double s) {
        System.out.println(s);
    }
    public static void printtln(int s) {
        System.out.println(s);
    }
    public static void printt(int s) {
        System.out.print(s);
    }
}
