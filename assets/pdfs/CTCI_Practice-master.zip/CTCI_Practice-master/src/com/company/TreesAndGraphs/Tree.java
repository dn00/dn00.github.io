package com.company.TreesAndGraphs;

import java.util.*;

import static com.company.QuickPrintString.printt;
import static com.company.QuickPrintString.printtln;

public class Tree {
    public static class TreeNode {
        int key;
        TreeNode left, right;

        // constructor
        TreeNode(int key) {
            this.key = key;
            left = null;
            right = null;
        }
    }

    static TreeNode root;
    static TreeNode temp = root;

    public static void inOrder(TreeNode temp) {
        if (temp == null) return;

        inOrder(temp.left);
        printtln(temp.key + " ");
        inOrder(temp.right);
    }
    public static void preOrder(TreeNode temp) {
        if (temp == null) return;
        printtln(temp.key + " ");
        inOrder(temp.left);
        inOrder(temp.right);
    }

    public static TreeNode createUnbalancedTree() {
        TreeNode node = new TreeNode(0);
        TreeNode temp = node;
        for (int i = 0; i < 6; ++i) {
            temp.left = new TreeNode(i);
            temp = temp.left;
        }
        temp = node;
        for (int j = 0; j < 13; ++j) {
            temp.right = new TreeNode(j);
            temp = temp.right;
        }

        return node;
    }
    public static TreeNode createBalancedBSTfromSortedArray(int[] arr, int start, int end) {
        // base case
        if (start > end) {
            return null;
        }

        int mid = (start + end) / 2;
        TreeNode node = new TreeNode(arr[mid]);

        // recursively add nodes on the left
        node.left = createBalancedBSTfromSortedArray(arr, start, mid - 1);

        // recursively add nodes on the right
        node.right = createBalancedBSTfromSortedArray(arr, mid + 1, end);

        return node;
    }

    public static void printListOfDepths(TreeNode root, HashMap<Integer, LinkedList<Integer>> map, int level) {
        if (root == null ){
            return;
        }

        if (map.containsKey(level))  {
            LinkedList<Integer> list = map.get(level);
            list.add(root.key);
        } else {
            LinkedList<Integer> list = new LinkedList<>();
            list.add(root.key);
            map.put(level, list);
        }

        ++level;
        printListOfDepths(root.left, map, level);

        printListOfDepths(root.right, map, level);
    }

    public static int isBalanced(TreeNode root) {
        if (root == null) {
            return -1;
        }

        int leftHeight = isBalanced(root.left);
        if (leftHeight == Integer.MIN_VALUE) return Integer.MIN_VALUE;

        int rightHeight = isBalanced(root.right);
        if (rightHeight == Integer.MIN_VALUE) return Integer.MIN_VALUE;

        int heightDiff = leftHeight - rightHeight;

        if (Math.abs(heightDiff) > 1) {
            return Integer.MIN_VALUE; // false
        } else {
            return Math.max(leftHeight, rightHeight) + 1;
        }
    }

    public static boolean isValidBST(Tree.TreeNode root) {
        if (root == null) {
            return true;
        }
//        printtln("key: " + root.key );

        if (root.left != null) {
//            printtln("key: " + root.key + "left.key" + root.left.key);

            if (root.left.key > root.key) {
                return false;
            }
        }
        if (root.right != null) {
//            printtln("key: " + root.key + "right.key" + root.right.key);

            if (root.right.key <= root.key ) {
                return false;
            }
        }
        boolean b = isValidBST(root.left) && isValidBST(root.right);
        return b;
    }
    static Queue<TreeNode> stack = new LinkedList<>();
    static TreeNode successorNode;
    public static TreeNode inOrderSuccessor(TreeNode temp, int n) {
        if (temp == null){
            return null;
        }

        inOrderSuccessor(temp.left, n);
        stack.add(temp);

//        if (temp.key > n) {
//
//        }

//        if (stack.peek().key > n) {
//            printtln("FOUND1 " + stack.pop().key);
//
//        }
//        stack.push(temp);
//
//        stack.pop();
        inOrderSuccessor(temp.right, n);

        int nn = stack.poll().key;
        printtln("stack: " + nn);
        if (nn == n) {
            if (stack.peek() != null) {
                printtln("peek: " + stack.peek().key);

                successorNode = stack.peek();
                return successorNode;
            } else {
                printtln("peek: " + temp.key);

            }
        }

//        if (temp.key != n) {
//            printtln("size(): " + stack.peek().key);
//
//            stack.pop();
//        }

//        if (stack.peek().key > n) {
//            printtln("FOUND2 " + stack.pop().key);
//
//        }
//        printtln("temp: " + temp.key);
//        printtln("size(): " + stack.size() + "nn: " + nn);

        return successorNode;
    }

    public static TreeNode getFirstAncestor(TreeNode rootNode, int q, int p) {
        if (rootNode == null) return new TreeNode(Integer.MAX_VALUE);

        TreeNode leftNode = getFirstAncestor(rootNode.left, q, p);
        if (rootNode.key == q || rootNode.key == p) {
            printtln("Found: leftNode " + leftNode.key + " Key: " + rootNode.key);
            return new TreeNode(p);
        }

        TreeNode rightNode = getFirstAncestor(rootNode.right, q, p);
        if (rootNode.key == q || rootNode.key == p) {
            printtln("Found: rightNode " + rightNode.key + " Key: " + rootNode.key);
            return new TreeNode(p);
        }
        printtln("p: " + p + " q: " + q + " Key: " + rootNode.key + " rightNode: " + rightNode.key + " leftNode: " + leftNode.key);
        if (rightNode.key == p || leftNode.key == p) {
            return rootNode;
        }
        if (leftNode.key != Integer.MAX_VALUE) {
            return leftNode;
        }
        if (rightNode.key != Integer.MAX_VALUE) {

            return rightNode;
        }
        return rootNode;
    }
    public static boolean checkSubtree(TreeNode t1, TreeNode t2) {
        LinkedList<TreeNode> q = new LinkedList<>();
        q.add(t1);


        while (!q.isEmpty()) {
            TreeNode node = q.poll();
            if (node.left != null) {
                ((LinkedList<TreeNode>) q).add(node.left);
            }
            if (node.right != null) {
                ((LinkedList<TreeNode>) q).add(node.right);
            }

            if (node.key == t2.key) {
                if (treesCheck(node, t2)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean treesCheck(TreeNode t1, TreeNode t2) {
        if (t2 == null && t1 != null) {
            return true;
        } else if (t1 == null && t2 != null) {
            return false;
        } else if (t2 == null) {
            return true;
        }

        boolean leftB = treesCheck(t1.left, t2.left);
        if (!leftB) {
            return false;
        }

        boolean rightB = treesCheck(t1.right, t2.right);
        if (!rightB) {
            return false;
        }

        return t1.key == t2.key;
    }

    public static int count = 0;
    public static int pathsWithSum(TreeNode node, int sum) {
        if (node == null ) {
            return Integer.MIN_VALUE;
        }
        int lastLeftNode = pathsWithSum(node.left, sum) + node.key;
        int result = node.key;
        printtln("lastLeftNode: " + lastLeftNode);

        if (lastLeftNode != Integer.MIN_VALUE) {
            if (lastLeftNode == sum) {
                ++count;
                result = sum - node.key;
            }
        }


        int rightLastNode = pathsWithSum(node.right, sum) + node.key;
        printtln("rightLastNode: " + rightLastNode);

        if (rightLastNode != Integer.MIN_VALUE) {
            if (rightLastNode == sum) {
                ++count;
                result = sum - node.key;
            }
        }


        printtln("count: " + count);
//        printtln("Key: " + node.key + " leftCount: " + leftCount + " rightCount: " + rightCount + " sum: " + sum);

        return result;
    }
}
