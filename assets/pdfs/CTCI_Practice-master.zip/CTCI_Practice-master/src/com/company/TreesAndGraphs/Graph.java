package com.company.TreesAndGraphs;


import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

import static com.company.QuickPrintString.printt;
import static com.company.QuickPrintString.printtln;

/** Implementation of a graph using adjacency list*/

public class Graph {
    private int V; //No. of vertices
    private LinkedList<Integer> adj[];

    public Graph(int v) {
        V = v;
        adj = new LinkedList[v];
        for (int i = 0; i < v; ++i) {
            adj[i] = new LinkedList<>();
        }
    }

    /** Add an edge into graph*/
    public void addEdge(int v, int w) {
        adj[v].add(w);
    }

    /** Return whether there is a route between two nodes*/
    public boolean isPathExist(int srcNode, int destNode) {
        boolean visited[] = new boolean[V];

        LinkedList<Integer> queue = new LinkedList<>();

        visited[srcNode] = true;
        queue.add(srcNode);

        while (queue.size() != 0) {
            srcNode = queue.poll();
            printtln(srcNode);
            for (int w : adj[srcNode]) {
                if (!visited[w]) {
                    if (w == destNode) {
                        return true;
                    }
                    visited[w] = true;
                    queue.add(w);
                }
            }
        }
        return false;
    }
    /** print bfs traversal given a source s*/
    public void BFS(int s) {
        //Mark all vertices as not visited
        //By default, each element in array is set to false
        boolean visited[] = new boolean[V];

        //Create a queue for BFS
        LinkedList<Integer> queue = new LinkedList<>();

        //Mark current node as visited and enqueue it
        visited[s] = true;
        queue.add(s);

        while (queue.size() != 0) {
            //Dequeue a vertex from queue and print it
            s = queue.poll();
            System.out.print(s + " ");

            //Get all adjacent vertices of dequeue vertex s
            // If a adjacent has not been visited, mark it visited and enqueue it

            for (int n : adj[s]) {
                if (!visited[n]) {
                    visited[n] = true;
                    queue.add(n);
                }
            }
        }
    }

    public static LinkedList<Character> createBuildOrder(char[] proj, LinkedList<char[]> dep) {
        LinkedList<Character> result = new LinkedList<>();
        Queue<Character> q = new LinkedList<>();
        LinkedList<Character> adjList[] = new LinkedList[proj.length];

        for (int i = 0; i < proj.length; ++i) {
            adjList[proj[i] - 'a'] = new LinkedList<>();
            ((LinkedList<Character>) q).add(proj[i]);
        }

        for (char[] arr : dep) {
            adjList[arr[0] - 'a'].add(arr[1]);
            q.remove(arr[1]);
        }


        boolean[] visited = new boolean[proj.length];

        while (!q.isEmpty()) {
            char v = q.poll();
            result.add(v);

            for (char c : adjList[v-'a']) {
                if (!visited[c-'a']) {
                    visited[c-'a'] = true;
                    ((LinkedList<Character>) q).add(c);
                }
            }
        }

        for (char c : result) {
            printtln("Order: " + c);
        }
        return result;
    }


}
