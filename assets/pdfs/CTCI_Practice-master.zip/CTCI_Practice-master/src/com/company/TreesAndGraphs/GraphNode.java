package com.company.TreesAndGraphs;

public class GraphNode {
    public Node[] nodes;
}

class Node {
    public String name;
    public Node[] children;
}