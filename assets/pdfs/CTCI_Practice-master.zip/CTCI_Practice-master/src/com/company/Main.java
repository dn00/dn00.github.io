package com.company;

import com.company.BitManip.FlipBitToWin;
import com.company.BitManip.NextNumber;
import com.company.LinkedList.LinkedList;
import com.company.SortAndSearch.*;
import com.company.StacksAndQueues.*;
import sun.awt.image.ImageWatched;

import java.util.Stack;

import static com.company.QuickPrintString.printt;
import static com.company.QuickPrintString.printtln;

public class Main {

    public static void main(String[] args) {
//        boolean isPerm = isPermmutation("test", "etst");
//        printtln("isPerm: " + isPerm);

//        printtln(URLify("Mr John Smith    ", 13));
//        PalindromePermutation.isPalindromePerm("A Toyota’s a Toyota.");
//        System.out.println(OneAway.isOneEditAway("pale", "pale"));

        /** 1.6 String Compression*/
//        printtln(StringCompression.StringCompression("AAaabcccccaaa"));

//        int[][] testMatrix = {{1,2,3,4,5}, {5,6,7,8,9}, {9, 0, 11, 12,13}, {13,14,15,16,17}, {18,19,20,21,22}};
//        MatrixProblems.RotateMatrix(testMatrix);
//        MatrixProblems.ZeroMatrix(testMatrix);
//

        /** Linked List*/

//        LinkedList ll = new LinkedList(5);
//
//        ll.appendToTail(3);
//        ll.appendToTail(2);
//        ll.appendToTail(7);
//        ll.appendToTail(1);
//        ll.appendToTail(4);
//        ll.appendToTail(7);
//        ll.appendToTail(4);
//        ll.appendToTail(2);
//        ll.appendToTail(1);
//        ll.appendToTail(2);
//        ll.appendToTail(3);

//        ll.removeDuplicates();
//        ll.printLinkedList();

//        LinkedList.Node n = ll.findkthToLastElement(0, ll.getHead());

//        ll.nthToLastElement(5, ll.getHead());
//        ll.printLinkedList();

//        printtln("\n");
//        ll.deleteAnyMiddleNode(n, ll.getHead());
//
//        ll.printLinkedList();
//

        /** Add two numbers */
//        LinkedList n1 = new LinkedList(7);
//        n1.appendToTail(1);
//        n1.appendToTail(6);
//
//        LinkedList n2 = new LinkedList(5);
//        n2.appendToTail(9);
//        n2.appendToTail(2);

//        LinkedList sumList = n1.addTwoNumbers(n2.getHead());
//        sumList.printLinkedList();

        /** In place and recursively*/
//        n1.addTwoNumbersForwardOrder(n2.getHead(), n1.getHead());
//        n1.printLinkedList();

        /** Palindrome */
//        LinkedList n1 = new LinkedList(1);
//        n1.appendToTail(2);
//        n1.appendToTail(3);
//        n1.appendToTail(5);
//        n1.appendToTail(3);
//        n1.appendToTail(2);
//        n1.appendToTail(1);
//
//        printtln("is Palindrome: " + n1.isPalindromeWithStack());

        /** Intersecting node*/

//        LinkedList n2 = new LinkedList(1);
//
//        n2.appendToTail(4);
//        n2.appendToTail(4);
//        n2.appendToTail(4);
//        LinkedList.Node n = n2.findkthToLastElement(1, n2.getHead());
//
//        LinkedList n1 = new LinkedList(1);
//
//        n1.appendToTail(4);
//        n1.appendToTail(665);
//        n1.appendToTail(3);
//        n1.appendToTail(5);
//        n1.appendToTail(2);
//        n1.appendToTail(6);
//        n1.appendNodeToTail(n);
//        n1.appendToTail(5);
//        n1.appendToTail(5);
//        n1.appendToTail(6);
//        n1.appendToTail(7);
//
//        LinkedList.Node nmn = n1.findIntersectNode(n1.getHead(), n2.getHead());

        /** Loop detection*/

        //create a looped list
//        LinkedList loopedList = new LinkedList(0);
//        loopedList.appendToTail(1);
//        loopedList.appendToTail(1);
//        loopedList.appendToTail(6);
//        LinkedList.Node n1 = loopedList.findkthToLastElement(1, loopedList.getHead());
//        loopedList.appendToTail(7);
//
//        loopedList.appendToTail(11);
//
////        loopedList.appendToTail(8);
////        loopedList.appendToTail(9);
//        LinkedList.Node n2 = loopedList.findkthToLastElement(1, loopedList.getHead());
//        n2.setNext(n1);
//
//        loopedList.loopDetection();

        // todo go over all code and analyze big(O) and space(O)

        /** Set of stacks */
//        SetOStack setStack = new SetOStack(3);
//
//        setStack.push(1);
//        setStack.push(2);
//        setStack.push(3);
//        setStack.push(4);
//        setStack.push(5);
//        setStack.push(6);
//        setStack.push(7);
//        setStack.push(8);
//        setStack.push(9);
//        setStack.push(10);
//
//        int stackSize = setStack.getSize();
//        printt(stackSize);
//        for (int i = 0; i < stackSize; ++i) {
//            printtln(setStack.pop());
//        }
        /** MyQueue implementation using two stacks*/
//
//        MyQueue myQ = new MyQueue();
//
//        myQ.add(1);
//        myQ.add(2);
//        myQ.add(3);
//        myQ.add(4);
//        myQ.add(5);

//        while (!myQ.isEmpty()) {
//            printtln(myQ.remove());
//        }

        /** Sort a stack using only another temp stack*/
//        Stack<Integer> testStack = new Stack<>();
//        testStack.push(4);
//        testStack.push(3);
//        testStack.push(1);
//        testStack.push(41);
//        testStack.push(4);
//
//        Stack<Integer> sortedStack = SortStack.SortTheStack(testStack);
//
//        while(!sortedStack.empty()) {
//            printtln(sortedStack.pop());
//        }

        /** Animal Shelter Queue*/
//        AnimalShelter animalShelter = new AnimalShelter();
//
//        animalShelter.enqueue(true);
//        animalShelter.enqueue(false);
//        animalShelter.enqueue(true);
//        animalShelter.enqueue(true);
//        animalShelter.enqueue(false);
//        animalShelter.printList();
//
//        animalShelter.dequeueAny();
//        animalShelter.printList();
//
//        animalShelter.dequeueCat();
//        animalShelter.printList();
//
//        animalShelter.dequeueDog();
//        animalShelter.printList();
//
        /** Bit manip*/
//        FlipBitToWin.FlipBitToWin(1775);
//        NextNumber.nextNumber(10);

//        LinkedList l1 = new LinkedList(1);
//        l1.appendToTail(2);
//        l1.appendToTail(4);
//
//        LinkedList l2 = new LinkedList(1);
//        l2.appendToTail(5);
//        l2.appendToTail(6);
//        l2.appendToTail(7);
//
//        LinkedList.Node res =  LinkedList.mergeTwoLists(l1.getHead(), l2.getHead());
//        LinkedList.printList(res);

        /** Search an element in pivoted array*/
//        int[] arr = {15,16,19,20,25,1,3,4,5,7,10,14};
//        printtln("Search Rotated Array: " + SearchRotatedArray.searchPivotedArray(arr, 15));

        /** Search a sparsed array filled with strings*/
//        String[] arr = {"at", "", "" , "" , "ball" , "", "", "car" , "" , "" , "dad", "" , ""};
//        printtln("Search Sparsed String Array: "  + SparseSearch.searchSparsedArray(arr, "at"));

        /** Sort an array starting with peak and alternating with valleys*/
//        int[] inputArr = {5,  8,  6,  2,  3,  4,  6};
//
//        int[] res = PeakAndValley.getPeakAndValley(inputArr);
//
//        for (int i : res) {
//            printt(i + " ");
//        }

        /** Uses bitset to print duplicates in array of size 32k*/
//
//        int[] arr = new int[32000];
//        for (int i = 0; i < arr.length; ++ i) {
//
//            arr[i] = i + 1;
//        }
//
//        arr[10] = 9;
//        arr[116] = 231;
//
//        PrintDuplicate.printDuplicates(arr);
        /** quick sort*/
        int arr[] = {5,9,6,4,1,1,1,1,1};
//        QuickSort.sort(arr,0,arr.length-1);
//        for (int i : arr) {
//            printt(i + " ");
//        }

        MergeSort.sort(arr,0,arr.length - 1);
        for (int i : arr) {
            printt(i + " ");
        }

    }

}
