package com.company.StringsAndArrays;

public class PemutationTest {
    public static boolean isPermmutation(String str1, String str2) {
        if (str1.length() != str2.length())
            return false;

        int firstStrSum = 0;
        int secondStringSum = 0;

        for (int i = 0; i < str1.length(); ++i) {
            firstStrSum += str1.charAt(i) - '0';
            secondStringSum += str2.charAt(i) - '0';
        }

        if (firstStrSum == secondStringSum) {
            return true;
        } else {
            return false;
        }
    }
}
