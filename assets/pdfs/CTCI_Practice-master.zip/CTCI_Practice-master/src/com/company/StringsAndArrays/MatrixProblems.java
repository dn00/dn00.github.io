package com.company.StringsAndArrays;

import java.util.HashMap;

import static com.company.QuickPrintString.printt;
import static com.company.QuickPrintString.printtln;

public class MatrixProblems {

    /** Given an MxN matrix, if an element is 0, zeroes out the row and column of that element
     * 1. First we find zero elements
     * 2. We keep track of the row and column integer using a HashMap where key is row, and column is value
     * 3. We zero out that row and column
     * */
    public static void ZeroMatrix(int[][] matrix) {
        HashMap<Integer, Integer> zeroXYMap = new HashMap<>();

        printMatrix(matrix);

        for (int i = 0; i < matrix.length; ++i) {
            for (int j = 0; j < matrix[i].length; ++j) {
                if (matrix[i][j] == 0) {
                    zeroXYMap.put(i,j);
                }
            }
        }

        for (HashMap.Entry entry : zeroXYMap.entrySet()) {
            int row = (Integer) entry.getKey();
            int col = (Integer) entry.getValue();
            for (int i = 0; i < matrix[row].length; ++i) {
                matrix[row][i] = 0;
            }
            for (int j = 0; j < matrix.length; ++j) {
                matrix[j][col] = 0;
            }
        }

        printMatrix(matrix);

    }


    /** Rotates matrix 90 degrees in-place
     * todo check if matrix ix NxN or not length 0, if not return false
     * */
    public static void RotateMatrix(int[][] matrix) {
        printMatrix(matrix);

        int max = matrix.length - 1;

//       int min = 0; changed this to i in the subsequent for loop

        for (int i = 0; i < max; ++i) {
            for (int j = max; j > i; --j) {
                int temp = matrix[i][max - j + i];
                matrix[i][max - j + i] = matrix[j][i];
                matrix[j][i] = matrix[max][j];
                matrix[max][j] = matrix[max - j + i][max];
                matrix[max - j + i][max] = temp;
            }
            --max;
        }

        printMatrix(matrix);
    }

    private static void printMatrix(int[][] matrix) {
        for (int[] array : matrix) {
            for (int arr : array) {
                printt(arr + " ");
            }
            printtln("");
        }
        printt("\n");

    }

}
