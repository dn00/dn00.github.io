package com.company.StringsAndArrays;

import java.util.HashMap;

import static java.lang.Math.abs;

/** Determines if a string is one edit away from the 2nd input string.
 * 1. Create charArray
 * 2. create character frequencyMap using HashMap
 * 3. count differences (value of 1). If count is greater than 1, then we have more than 1 edit*/

//todo Not finished. We need to redo this problem and test each condition of the problem.

public class OneAway {
    public static boolean isOneEditAway(String a, String b){

        //check deletion or addition.
        if (abs(a.length() - b.length()) > 1) {
            return false;
        }

        char[] charArrayA = a.toCharArray();
        char[] charArrayB = b.toCharArray();

        int differenceCount = 0;

        //todo difference count by difference in length
        if (a.length() > b.length()) {
            for (int i = 0; i < charArrayA.length; ++i) {
                if (charArrayA[i] != charArrayB[i]) {
                    ++differenceCount;
                    if (differenceCount > 1) {
                        return false;
                    }
                }
            }
        } else {
            for (int i = 0; i < charArrayB.length; ++i) {
                if (charArrayB[i] != charArrayA[i]) {
                    ++differenceCount;
                    if (differenceCount > 1) {
                        return false;
                    }
                }
            }
        }

        HashMap<Character, Integer> freqMap = new HashMap<Character, Integer>();

        updateFreqMap(freqMap, charArrayA);
        updateFreqMap(freqMap, charArrayB);

        return isOneAway(freqMap);
    }

    /** Counts the number of differences and returns true if count is 1. Otherwise, return false*/
    private static boolean isOneAway(HashMap<Character, Integer> map) {
        int differenceCount = 0;
        for (HashMap.Entry entry : map.entrySet()) {
            if ((Integer) entry.getValue() == 1) {
                System.out.println("found differ");
                if (differenceCount > 1) {
                    return false;
                }
                ++differenceCount;
            }
        }
        return true;
    }

    /** Updates a hashMap with value as the count of characters found in a char. array */
    private static HashMap<Character, Integer> updateFreqMap(HashMap<Character, Integer> map, char[] cArray) {
        for (char c : cArray) {
            if (map.get(c) == null) {
                map.put(c, 1);
            } else {
                map.put(c, map.get(c) + 1);
            }
        }

        return map;
    }

}
