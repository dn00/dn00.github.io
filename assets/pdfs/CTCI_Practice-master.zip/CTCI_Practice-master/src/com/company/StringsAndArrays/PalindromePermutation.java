package com.company.StringsAndArrays;

import java.util.Arrays;
import java.util.HashMap;

/** Determines if a string is a permutation of a palindrome.
 * 1. and convert to char araray and sort
 * 2. count letters via frequency map using hashmap
 * 3. count odd frequencies
 * 4. if frequency of odd is no more than 1, then it's a permutation of palindrome
 *
 * */

//todo Try frequency map using normal arrays, normalizing alphabet to numerical values.
//todo do we need to sort?

public class PalindromePermutation {
    public static boolean isPalindromePerm(String s) {
        char[] charArray = s.toLowerCase().toCharArray();
        Arrays.sort(charArray);

        HashMap<Character, Integer> freqMap = createLetterFrequencyMap(charArray);

        boolean isPermutationOfPalindrome = isOneOdd(freqMap);
        System.out.print(s + ": " + isPermutationOfPalindrome);

        //todo
        return false;
    }
    /* returns true if there is one single occurrence of a letter*/
    private static boolean isOneOdd(HashMap<Character, Integer> map) {
        boolean foundOdd = false;

        for (HashMap.Entry entry : map.entrySet()) {
            if ((Integer) entry.getValue() % 2 != 0) {
                if (foundOdd) {
                    return false;
                }
                foundOdd = true;
            }
        }
        return true;
    }


    /* counts occurrences of letters with hashmap */
    private static HashMap<Character, Integer> createLetterFrequencyMap(char[] array) {
        HashMap<Character, Integer> freqMap = new HashMap<Character, Integer>();


        for (char c : array) {
            if (c != ' ' && Character.getNumericValue(c) >= 10 && Character.getNumericValue(c) <= 35) {
                if (freqMap.get(c) == null)
                    freqMap.put(c, 1);
                else
                    freqMap.put(c, freqMap.get(c) + 1);
//            System.out.println("Char: " + c + " " + freqMap.get(c));
            }
        }
        return freqMap;
    }

}
