package com.company.StringsAndArrays;

/** Replaces whitespace in a string with "%20" */
public class URLify {
    public static String URLify(String str, int length) {
        int numOfSpaces = 0;
        for (int i = 0; i < str.length(); ++i) {
            if (str.charAt(i) == ' ')
                ++numOfSpaces;
        }

        String spaceCode = "%20";
        char[] charArray = new char[str.length() + (numOfSpaces * 3)];

        int nextCharIndex = 0;
        for (int i = 0; i < length; ++i) {
            if (str.charAt(i) == ' ') {
                for (int j = 0; j < 3; ++j) {
                    charArray[nextCharIndex] = spaceCode.charAt(j);
                    ++nextCharIndex;
                }
            } else {
                charArray[nextCharIndex] = str.charAt(i);
                ++nextCharIndex;
            }
        }

        StringBuilder stringBuilder = new StringBuilder();
        for (char c : charArray) {
            stringBuilder.append(c);
        }

        return stringBuilder.toString();
    }
}
