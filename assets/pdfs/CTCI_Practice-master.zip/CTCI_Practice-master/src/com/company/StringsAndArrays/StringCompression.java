package com.company.StringsAndArrays;

import java.util.HashMap;

/** Compresses a string base on frequency of a letter. e.g. aaabbbcc = a3b3c2. Returns original if compressed string is larger than original.
 * 1. Create charData class that stores the character and its frequency
 * This CharData class will be reused. Instead of creating a new instance for every different letter, we use the reset() method.
 * 2. Convert input String to CharArray
 * 3. Iterate though input CharArray and create CharData for each repeating letter, reset CharDataHolder when it's a new letter.
 *         Build the compressed string with letter and frequency of the letter.
 * 4. Compare if new compressed String is smaller than the original
 * 5. Return compressed String if smaller than original, otherwise return original String.
 *
 * //todo count length of compressed and compare before doing compression
 *
 * */
public class StringCompression {
    private static class CharData {
        char ch;
        int freq = 0;

        public CharData(char c) {
            ch = c;

        }
        public void setChar(char c) {
            ch = c;
        }
        public char getChar() {
            return ch;
        }
        public int getFreq() {
            return freq;
        }

        public void incFreq() {
            ++freq;
        }

        public void reset() {
            ch = ' ';
            freq = 0;
        }
    }
    public static String StringCompression(String s) {
        char[] charArray = s.toCharArray();

        CharData charDateHolder = new CharData(charArray[0]);
//        char currentChar;

        StringBuilder stringBuilder = new StringBuilder();
        for (char c : charArray) {
            if (charDateHolder.getChar() != c) {
                stringBuilder.append(charDateHolder.getChar());
                stringBuilder.append(charDateHolder.getFreq());
                charDateHolder.reset();
                charDateHolder.setChar(c);
            }
            charDateHolder.incFreq();
        }

        stringBuilder.append(charDateHolder.getChar());
        stringBuilder.append(charDateHolder.getFreq());

        //todo write condition for when compressed String is larger than input String
        String compressedString = stringBuilder.toString();

        if (isCompressedStringLarger(compressedString, s))
            return s;
        else
            return compressedString;

    }

    public static boolean isCompressedStringLarger(String compressed, String original) {
        if (compressed.length() > original.length()) {
            return true;
        }
        return false;
    }
}
