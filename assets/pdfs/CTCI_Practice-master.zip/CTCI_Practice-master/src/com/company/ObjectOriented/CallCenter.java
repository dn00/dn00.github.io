package com.company.ObjectOriented;

import java.util.ArrayList;
import java.util.Arrays;

public class CallCenter {
    public enum EmployeeLevel {
        Repsondent(0), Manager(1), Director(2);
        private int levelValue;
        EmployeeLevel(int v) { this.levelValue = v; }
        public int getLevelValue() { return levelValue; }
        public static EmployeeLevel getLevelFromValue(int v) {
            if (v == 0) {
                return Repsondent;
            } else if (v == 1) {
                return Manager;
            } else {
                return Director;
            }
        }
    }

    public class Employee {
        EmployeeLevel employeeLevel;
        public Employee(int level) {
            employeeLevel = EmployeeLevel.getLevelFromValue(level);
        }

        public int getEmployeeLevelValue() {
            return employeeLevel.getLevelValue();
        }
    }

    public class CallHandler {
        private Employee[] employees = {new Employee(0), new Employee(0),
                new Employee(1), new Employee(2)};

        public CallHandler() {

        }
        public void dispatchCall() {
            Arrays.sort(employees);
            
        }
    }


}
