package com.company.SortAndSearch;

import static com.company.QuickPrintString.printtln;

public class SparseSearch {
    public static int searchSparsedArray(String[] arr, String key) {
        return binarySparsedSearch(arr, 0, arr.length -1, key);
    }
    public static int binarySparsedSearch(String[] arr, int low, int high, String key) {
        if (high < low) return -1;

        int mid = (high + low) / 2;
        if (arr[mid].equals("")) {
            int left = low;
            int right = high;

            while (true) {
                if (left == right) return -1;

                if (left >= low && !arr[left].equals("")) {
                    printtln("Found mid: " + left);
                    mid = left;
                    break;
                }
                if (right <= high && !arr[right].equals("")) {
                    printtln("Found mid: " + right);

                    mid = right;
                    break;
                }
                ++left;
                --right;
            }
        }
        printtln(" test: " + arr[mid]);

        if (arr[mid].equals(key)) return mid;
        if (arr[mid].compareTo(key) > 0) return binarySparsedSearch(arr, low, mid - 1, key);
        return binarySparsedSearch(arr, mid + 1, high, key);
    }
}
