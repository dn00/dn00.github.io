package com.company.SortAndSearch;

public class PeakAndValley {
    public static int[] getPeakAndValley(int[] arr) {
        if (arr == null) return null;
        if (arr.length == 1) return arr;

        for (int i = 0; i < arr.length - 1; ++i) {
            if (i % 2 == 0) {
                if (arr[i] < arr[i + 1]) {
                    swap(arr, i);
                }
            } else if (i % 2 == 1) {
                if (arr[i] > arr[i + 1]) {
                    swap(arr, i);
                }
            }
        }
        return arr;
    }

    private static void swap(int[] arr, int i) {
        int temp = arr[i];
        arr[i] = arr[i + 1];
        arr[i + 1] = temp;
    }
}
