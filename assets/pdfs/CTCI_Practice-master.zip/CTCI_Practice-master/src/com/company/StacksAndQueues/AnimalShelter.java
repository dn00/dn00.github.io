package com.company.StacksAndQueues;

import java.util.LinkedList;

import static com.company.QuickPrintString.printtln;

/** Uses Linkedlist as queue for fifo of animals
 *
 */

public class AnimalShelter {
    private class Animal {
        public String type;
        public Animal() {

        }
        public String getAnimalType() {
            return type;
        }
    }
    private class Dog extends Animal {
        public Dog() {
            type = "Dog";
        }
    }

    private class Cat extends Animal {
        public Cat() {
            type = "Cat";
        }
    }

    LinkedList<Animal> animalLinkedList = new LinkedList<>();

    public AnimalShelter() {

    }

    public void enqueue(boolean isCat) {
        if (isCat) {
            animalLinkedList.add(new Cat());
        } else {
            animalLinkedList.add(new Dog());
        }
    }

    public Animal dequeueAny() {
        return animalLinkedList.removeFirst();
    }

    public Animal dequeueDog() {
        for (Animal a : animalLinkedList) {
            if (a instanceof Dog) {
                animalLinkedList.remove(a);
                return a;
            }
        }
        return null;
    }

    public Animal dequeueCat() {
        for (Animal a : animalLinkedList) {
            if (a instanceof Cat) {
                animalLinkedList.remove(a);
                return a;
            }
        }
        return null;
    }

    public void printList() {
        printtln("");
        for (Animal a : animalLinkedList) {
            printtln(a.getAnimalType());
        }
    }
}
