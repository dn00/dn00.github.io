package com.company.StacksAndQueues;

import java.util.Stack;

import static com.company.QuickPrintString.printtln;

/** A queue class using just two stacks*/
public class MyQueue {
    private Stack<Integer> addStack;
    private Stack<Integer> popStack;
    private int size = 0;

    public MyQueue() {
        addStack = new Stack<Integer>();
        popStack = new Stack<Integer>();
    }

    public void add(int i) {
        addStack.push(i);
        ++size;
    }

    public int remove() {
        if (popStack.size() == 0) {
            swapToPopStack();
        }
        --size;
        return popStack.pop();
    }

    public boolean isEmpty() {
        return size == 0;
    }

    private void swapToPopStack() {
        while (!addStack.empty()) {
            popStack.push(addStack.pop());
        }
    }
}
