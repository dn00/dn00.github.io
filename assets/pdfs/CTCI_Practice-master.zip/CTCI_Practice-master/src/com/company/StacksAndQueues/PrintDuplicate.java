package com.company.StacksAndQueues;

import java.util.BitSet;

import static com.company.QuickPrintString.printt;
import static com.company.QuickPrintString.printtln;

public class PrintDuplicate {
    public static void printDuplicates(int[] arr) {
        if (arr.length == 0) return;

        BitSet bitSet = new BitSet(arr.length);
        printtln("Array length: " + arr.length);

        for (int i : arr) {
            if (bitSet.get(i)) {
                printtln("Found duplicate: " + i);
            }
            bitSet.set(i);
        }
    }
}
