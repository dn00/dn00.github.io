package com.company.StacksAndQueues;

import java.util.Stack;

/** Sort a stack using another temp stack
 * We iterate and find the max by pushing a popped item into the temp stack.
 *
 * */
public class SortStack {
    public static Stack<Integer> SortTheStack(Stack<Integer> stack) {
        Stack<Integer> tempStack = new Stack<>();
        int max = -1, popped;
        int count = 0;
        int size = stack.size();
        boolean removedDup;

        while (count < size) {
            for (int i = 0; i < (size - count); ++i) {
                popped = stack.pop();
                if (popped > max)
                    max = popped;

                tempStack.push(popped);
            }

            stack.push(max);
            ++count;
            removedDup = false;

            while(!tempStack.empty()) {
               popped = tempStack.pop();
               if ((popped == max) && !removedDup) {
                   removedDup = true;
               } else {
                   stack.push(popped);
               }
            }

            max = -1;
        }

        return stack;
    }
}
