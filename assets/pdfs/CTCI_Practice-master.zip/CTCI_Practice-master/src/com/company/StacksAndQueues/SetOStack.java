package com.company.StacksAndQueues;

import java.util.EmptyStackException;
import java.util.Stack;

import static com.company.QuickPrintString.printtln;

/** Set of stacks using an array
 * todo modify so that pop() takes into account of a previous non-full stack*/
public class SetOStack {
    private Stack[] stackSet = new Stack[99];
    private Stack<Integer> stackHistory = new Stack<>();
    private int workingStack = 0;
    private int size = 0;
    private int maxItems;

    /** */
    public SetOStack(int maxNumOfItems) {
        maxItems = maxNumOfItems;
        stackSet[workingStack] = new Stack<Integer>();
    }

    public void push(int item) {
        if (stackSet[workingStack].size() > maxItems) {
            addStack();
        }
//        if (stackHistory.size() > 0) {
////            printtln(">> Current stack: " + workingStack + " stack size:" + stackSet[workingStack].size());
//            stackSet[stackHistory.pop()].push(item);
//        } else {
////            printtln("Current stack: " + workingStack + " stack size:" + stackSet[workingStack].size());
//            stackSet[workingStack].push(item);
//        }
        stackSet[workingStack].push(item);

    }

    public int pop() {
        if (size == 0 && stackSet[workingStack].size() == 0) {
            throw new EmptyStackException();
        }

        if (stackSet[workingStack].size() == 0) {
            removeStack();
        }
//        printtln("POPPED WorkingStack: " + workingStack + " stacksize :" + stackSet[workingStack].size());
        return (Integer) stackSet[workingStack].pop();

    }

    public int popAt(int index) {
        if (index > size)
            throw new EmptyStackException();
        if (stackSet[index].size() == 1) {
            stackHistory.push(index);
        }
        return (Integer) stackSet[index].pop();
    }

    public int getSize() {
        int sizeSum = 0 ;
        for (int i =0; i < size; ++i) {
             sizeSum += stackSet[i].size();
        }
        return sizeSum + stackSet[workingStack].size();
    }

    public void getInfo() {
        printtln("///////////////////");
        printtln("stackSet size: " + size);
        printtln("working Stack: " + workingStack);
        printtln("Working stack size: " + stackSet[workingStack].size());
        printtln("///////////////////");

    }
    private void addStack() {
        if (stackHistory.size() > 0) {
            workingStack = stackHistory.pop();
        } else {
            ++size;
            workingStack = size;
        }
        stackSet[workingStack] = new Stack<Integer>();
//        printtln("Added stack - size: " + size);
    }

    private void removeStack() {
        stackSet[workingStack] = null;
        --size;
        workingStack = size;
//        printtln("Removed stack - size: " + workingStack);

    }
}
