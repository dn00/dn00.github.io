package com.company.BitManip;

import static com.company.QuickPrintString.printtln;

public class FlipBitToWin {
    public static int FlipBitToWin(int num) {
        if (~num == 0) return Integer.BYTES * 8;

        int currentLength = 0;
        int previousLength = 0;
        int maxLength = 1;

        while (num != 0) {
            if ((num & 1) == 1) {
                printtln(1);
                ++currentLength;
            } else if ((num & 1 ) == 0) {
                previousLength = ((num & 2) == 0 ? 0 : currentLength);
                currentLength = 0;
                printtln(0);
            }
            maxLength = Math.max(previousLength + currentLength + 1, maxLength);
            num = num >>> 1;
        }
        printtln("Max Length: " + maxLength);
        return maxLength;
    }


}
