package com.company.BitManip;

import static com.company.QuickPrintString.printt;
import static com.company.QuickPrintString.printtln;

public class NextNumber {
    public static void nextNumber(int num) {
        if (num == 0) {
            printtln("0");
        }

        while (num != 0) {
            if ((num & 1) == 0) {
                printtln("0");
            } else if ((num & 1) == 1) {
                printtln(1);
            }
            num >>>= 1;
        }

    }
}
