package com.company.BitManip;

public class Insertion {
    public static int insertMInN(int n, int m, int i, int j) {


        return 0;
    }
}
