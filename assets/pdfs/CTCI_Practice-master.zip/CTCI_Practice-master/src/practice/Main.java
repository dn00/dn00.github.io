package practice;


import com.company.TreesAndGraphs.Graph;
import com.company.TreesAndGraphs.Tree;

import javax.swing.tree.TreeNode;
import java.util.*;

import static com.company.QuickPrintString.printt;
import static com.company.QuickPrintString.printtln;

public class Main {

    public static void main(String[] args) {
//        int[] arr = {3, 2, 4};
//        Solution.twoSum(arr, 6);
//        Solution.ListNode n = Solution.ListNode.
//        System.out.println(Solution.longestPalindrome("cbbd"));
//        printtln(Solution.convert("PAYPALISHIRING", 3));
//        printtln(Solution.reverse(2147483647));
//        printtln(Solution.isPalindrome(11));
//        printtln(Solution.maxArea(new int[] {1,8,6,2,5,4,8,3,7}));
//        Solution.intToRoman(1994);
//        printtln(Solution.intToRoman(21));
//        printtln(Solution.intToRoman(9001));
//        int[] arr = {-1, 0, 1, 2, -1, -4};
//        Solution.threeSum(arr);
//        int[] arr = {0,2,1,-3};
//        Solution.threeSumClosest(arr, 1);
//        printtln(Solution.longestValidParentheses(")))(()"));


//        Scanner reader = new Scanner(System.in);  // Reading from System.in
//        int n = reader.nextInt(); // Scans the next token of the input as an int.

//        Graph g = new Graph(4);
//        g.addEdge(0, 1);
//        g.addEdge(0, 2);
//        g.addEdge(1, 2);
//        g.addEdge(2, 0);
//        g.addEdge(2, 2);
//        g.addEdge(3, 3);
//
//        printtln(g.isPathExist(0, 3));
//


//        Scanner reader = new Scanner(System.in);
//        int testCases = reader.nextInt();
//
//        for (int cases = 0; cases < testCases; ++cases) {
//            int N = reader.nextInt();
//            int M = reader.nextInt();
//            int count = 0;
//            ArrayList<char[]> listOfArrays = new ArrayList<>();
//            LinkedList<int[]> queue = new LinkedList<>();
//
//            for (int i = 0; i < N; ++i) {
//                char[] arr = reader.next().toCharArray();
//                listOfArrays.add(arr);
//            }
//
//            for (int j = 0; j < N; ++j) {
//                for (int k = 0; k < M; ++k) {
//                    if (listOfArrays.get(j)[k] == 'X') {
//                        queue.add(new int[] {j,k});
//                        listOfArrays.get(j)[k] = 'O';
//                    }
//
//                    while(queue.size() != 0) {
//                        int[] out = queue.poll();
//                        int x = out[0]; int y = out[1];
//                        listOfArrays.get(x)[y] = 'O';
//
////                        printtln("pulled: [" + x + ',' + y + "]");
//
//                        int leftY = (out[1] - 1) < 0 ? 0 : (out[1] - 1);
//                        int rightY = (out[1] + 1) >= M ? M - 1 : (out[1] + 1);
//                        if (listOfArrays.get(x)[leftY] == 'X') {
//                            queue.add(new int[] {x, leftY});
//                        }
//                        if (listOfArrays.get(x)[rightY] == 'X') {
//                            queue.add(new int[] {x, rightY});
//                        }
//
//                        int topX = (out[0] - 1) < 0 ? 0 : (out[0] - 1);
//                        int bottomX = (out[0] + 1) >= N ? N - 1: (out[0] + 1);
//                        if (listOfArrays.get(topX)[y] == 'X') {
//                            queue.add(new int[] {topX, y});
//                        }
//                        if (listOfArrays.get(bottomX)[y] == 'X') {
//                            queue.add(new int[] {bottomX, y});
//                        }
//                        if (queue.size() == 0) {
//                            ++count;
//                        }
//                    }
//
//                }
//            }
//            System.out.print(count);
//
//        }
//

        /**  a. Create a balanced BST from a sorted array
         *   b. create D levels of linkedlists with level's integers
         *   c. Check if a tree is balanced. (No more than difference of 1 on levels.
         *   */
        int[] arr = {1,2,3,4,5,6,7,8,9,10};
        int[] arrr = {1,2,3,4};

        Tree.TreeNode BSTRoot = Tree.createBalancedBSTfromSortedArray(arr, 0, arr.length - 1);
        Tree.TreeNode BSTRoott = Tree.createBalancedBSTfromSortedArray(arrr, 0, arrr.length - 1);

//        Tree.inOrder(BSTRoot);

        HashMap<Integer, LinkedList<Integer>> map = new HashMap<>();
        Tree.printListOfDepths(BSTRoot, map, 0);

        for (Map.Entry entry : map.entrySet()) {
            printt("LEVEL " + (Integer) entry.getKey() + ": ");
            LinkedList<Integer> list = (LinkedList<Integer>) entry.getValue();
            for (int i : list) {
                printt("," + i);
            }
            printtln("");
        }

        // Test if our created balanced BST is actually balanced.
        printtln("isBalanced: " + Tree.isBalanced(BSTRoot));

        //Create an unbalanced tree.
        Tree.TreeNode unbalancedTree = Tree.createUnbalancedTree();
        HashMap<Integer, LinkedList<Integer>> map2 = new HashMap<>();
        Tree.printListOfDepths(unbalancedTree, map2, 0);

//        for (Map.Entry entry : map2.entrySet()) {
//            printt("LEVEL " + (Integer) entry.getKey() + ": ");
//            LinkedList<Integer> list = (LinkedList<Integer>) entry.getValue();
//            for (int i : list) {
//                printt("," + i);
//            }
//            printtln("");
//        }

//        printtln("isBalanced: " + Tree.isBalanced(unbalancedTree));


//        printtln(Tree.isValidBST(BSTRoot));
//        Tree.TreeNode successorNode = Tree.inOrderSuccessor(BSTRoot, 1);

//        Tree.inOrder(successorNode);
//        printtln(Tree.inOrderSuccessor(BSTRoot, 2).);

        /** build order*/
//        char[] projects = {'a', 'b', 'c', 'd', 'e', 'f'};
//        LinkedList<char[]> dependencies = new LinkedList<>();
//
//        dependencies.add(new char[] {'a', 'd'});
//        dependencies.add(new char[] {'f', 'b'});
//        dependencies.add(new char[] {'b', 'd'});
//        dependencies.add(new char[] {'f', 'a'});
//        dependencies.add(new char[] {'d', 'c'});
//
//        Graph.createBuildOrder(projects, dependencies);
//

        /** Get first ancestor of 2 nodes*/
//        Tree.TreeNode t = Tree.getFirstAncestor(BSTRoot, 1,4);
//        Tree.inOrder(t);


//        printtln("Subtree exists: " + Tree.checkSubtree(BSTRoot, BSTRoott));

//
//        int[] pathSumTest = {1,2,3,4,5,6,7,8,9,10};
//        Tree.TreeNode pathSumTestRoot = Tree.createBalancedBSTfromSortedArray(pathSumTest, 0, pathSumTest.length - 1);
//
//        printtln("PathsWithSum: " + Tree.pathsWithSum(pathSumTestRoot, 5));
//
//        /** Grouped anagrams*/
//        String[] s = {"eat", "tea", "tan", "ate", "nat", "bat"};
//        List<List<String>> l = Solution.groupAnagrams(s);
//
//        for (List<String> ll : l) {
//            for (String str : ll) {
//                printt(" " + str);
//            }
//            printtln("");
//        }
//
        /** Merge sorted k-lists*/
    }

}
