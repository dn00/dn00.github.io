package practice;

import com.company.TreesAndGraphs.Tree;

import java.util.*;

import static com.company.QuickPrintString.printt;
import static com.company.QuickPrintString.printtln;

/** For leetcdes problems*/

class Solution {
    public class ListNode {
      int val;
      ListNode next;
      ListNode(int x) { val = x; }
    }

    public static int lengthOfLongestSubstring(String s) {
        if (s.length() == 0 || s.length() == 1) {
            return s.length();
        }

        char[] charArray = s.toCharArray();
        HashMap<Character,Integer> map = new HashMap<>();

        int max = 0;
        int currentLength = 0;
        int i = 0;

        for (char c : charArray) {
            if (map.containsKey(c)) {
                currentLength = 1;
                printtln("currentLength: " + currentLength);

                map.put(c, i);

            } else {
                map.put(c,i);
                ++currentLength;

            }
            max = Math.max(currentLength, i-max+1);
            printtln("currentMax: " + max);
            ++i;
        }
        return max;
    }
    public static int longestValidParentheses(String s) {
        if (s.length() == 0 || s.length() == 1) {
            return 0;
        }

        Stack<Character> open = new Stack<>();

        int count = 0;
        int max = 0;
        boolean isLastPushOpen = false;
        int lastCount = 0;
        for (int i = 0; i < s.length(); ++i) {
            if (s.charAt(i) == '(') {
                open.push(s.charAt(i));
                if (isLastPushOpen) {
//                    printtln("open");
                    lastCount = count;

                    count = 0;
                    isLastPushOpen = false;
                }
                isLastPushOpen = true;

            } else if (!open.isEmpty()) {
                if (open.pop() == '(' && s.charAt(i) == ')') {
                    count += 2;
                }
                isLastPushOpen = false;

            } else {
                count = 0;
                isLastPushOpen = false;
            }
            if (i == s.length() - 1) {
//                printtln("length");

                if (open.size() == 0) {
//                    printtln("size" + lastCount);

                    max += 2 * lastCount;
                }
            }
            max = Math.max(max, count);
        }

        return max;
    }

    public static String convert(String s, int numRows) {
        if (s.length() == 1 || s.length() < numRows - 1) return s;
        boolean zig = true;
        char[][] charArray = new char[numRows][(s.length() + 1/(numRows))];

        StringBuilder stringBuilder = new StringBuilder();

        int indx = 0;
        int i = 0, j = 0;

        while (indx < s.length()) {
            charArray[j][i] = s.charAt(indx);
            if (zig) {
                ++j;
                if (j > numRows - 1) {
                    j = numRows - 2;
                    ++i;
                    zig = false;
                }
            }
            else {
                --j;
                ++i;

                if (j < 0) {
                    j = 1;
                    zig = true;
                }
            }
            ++indx;
        }

        for (char[] c : charArray) {
            for (char cc : c) {
                if (cc != '\u0000')
                stringBuilder.append(cc);
            }
        }
        return stringBuilder.toString();
    }

    public static int reverse(int x) {
        int newInt = 0;
        if (x < 10 && x > -10) {
            return x;
        }

        boolean isNeg = x < 0;

        if (isNeg) {
            x = -x;
        }
        if (x >= 2147483647) {
            return 0;
        }

        int digit = 0, lastDigit = 0;
        boolean digitCheck = false;

        while (x > 0) {
            printtln(newInt);
            if (newInt == 0) {
                digitCheck = false;
            }
            newInt += (int)(Math.pow(10,(int) (Math.log10(x)))) * (x % 10);
            lastDigit = digit;
            digit = (int) Math.log10(newInt);

            if (lastDigit != digit && digitCheck) {
                return 0;
            }
            digitCheck = true;
            x /= 10;

        }

        if (isNeg) {
            newInt = -newInt;
        }

        return newInt;
    }

    /** Uses a frequency map to keep count of elements. If there are more than 1 element with
     * odd frequency, return false. Input is not a palindrome*/
    public static boolean isPalindrome(int x) {
        if (x < 0) return false;
        if (x < 10) return true;

        Stack<Integer> stack = new Stack<>();

        int newNum;
        int length = (int) Math.log10(x) + 1;
        int mid;
        boolean isEven;
        if (length % 2 == 0) {
            mid = (length / 2);
            isEven = true;
        } else {
            mid = (length / 2) + 1;
            isEven = false;
        }

        while (x > 0) {
            newNum = x % 10;
//            printtln("newNum: " + newNum + " Mid: " + mid);

            if (length > mid) {
//                printtln("push: " + newNum);
                stack.push(newNum);
            } else if (length < mid){
                if (stack.size() > 0) {
                    int pop = stack.pop();
//                    printtln("pop: " + newNum + "stackpop: " + pop);
                    if (newNum != pop) {
                        return false;
                    }
                } else if (length > 0) {

                    return false;
                }
            } else if (length == mid && (length == 1 || isEven)) {
                if (newNum != stack.pop()) {

                    return false;
                }
            }
            x /= 10;
            --length;
        }

        return true;
    }
    public static int maxArea(int[] height) {
        if (height.length == 1) return 0;
        if (height.length == 2) {
            return Math.min(height[0], height[1]);
        }

        int max = 0;

        for (int i = 0; i < height.length - 1; ++i) {
            for (int j = i + 1; j < height.length; ++j) {
                int area = Math.min(height[i],height[j]) * (j - i);
                max = Math.max(area, max);
            }
        }
        return max;
    }


    public static String intToRoman(int n) {
        StringBuilder stringBuilder = new StringBuilder();
        int sub = 0;

        while (n > 0) {
            if (n >= 1000) {
                stringBuilder.append("M");
                sub = 1000;
            } else if (n >= 900) {
                stringBuilder.append("CM");
                sub = 900;
            } else if (n >= 500) {
                stringBuilder.append("D");
                sub = 500;
            } else if (n >= 400) {
                stringBuilder.append("CD");
                sub = 400;
            } else if (n >= 100) {
                stringBuilder.append("C");
                sub = 100;
            } else if (n >= 90) {
                stringBuilder.append("XC");
                sub = 90;
            } else if (n >= 50) {
                stringBuilder.append("L");
                sub = 50;
            } else if (n >= 40) {
                stringBuilder.append("XL");
                sub = 40;
            }  else if (n >= 10) {
                stringBuilder.append("X");
                sub = 10;
            } else if (n == 9) {
                stringBuilder.append("IX");
                sub = 9;
            }  else if (n >= 5) {
                stringBuilder.append("V");
                sub = 5;
            } else if (n == 4) {
                stringBuilder.append("IV");
                sub = 4;
            } else if (n < 4) {
                stringBuilder.append("I");
                sub = 1;
            }

            n -= sub;

        }

        return stringBuilder.toString();
    }

    public static String longestPalindrome(String s) {
        if (s == null) return null;
        if (s.length() == 1 || s.length() == 0) return s;

        int[] longestSub = {0, 0};
        int k = 0, j =0;

        for (int i = 0; i < s.length() - 1; ++i) {
            k = i;
            j = i + 1;

            //todo can implement these while loops as method
            while (s.charAt(k) == s.charAt(j)) {
                if ((longestSub[1] - longestSub[0] < (j-k))) {
                    longestSub[0] = k;
                    longestSub[1] = j;
                }
                ++j;
                --k;
                if (k < 0 || j > s.length() - 1)
                    break;
            }
            k = i;
            j = i + 2;
            if (j > s.length() - 1) break;

            while (s.charAt(k) == s.charAt(j)) {
                if ((longestSub[1] - longestSub[0] < (j-k))) {
                    longestSub[0] = k;
                    longestSub[1] = j;
                }
                ++j;
                --k;
                if (k < 0 || j > s.length() - 1)
                    break;
            }
        }
        return s.substring(longestSub[0], longestSub[1] + 1);
    }

    public static List<List<Integer>> threeSum(int[] nums) {
        List<List<Integer>> list = new ArrayList<>();
        HashMap<Integer, Integer> map = new HashMap<>();

        if (nums.length < 3) {
            return list;
        }

        for (int i = 0; i < nums.length; ++i) {
            map.put(nums[i], i);
        }

        for (int i = 0; i < nums.length; ++i) {

            for (int j = i + 1; j < nums.length; ++j) {
                int n = -(nums[j] + nums[i]);
                if (map.containsKey(n)) {
                    if (map.get(n) != i && map.get(n) != j) {
                        List<Integer> solutionSet = new ArrayList<>();
                        solutionSet.add(n);
                        solutionSet.add(nums[j]);
                        solutionSet.add(nums[i]);
                        map.remove(n);
                        map.remove(nums[j]);
                        map.remove(nums[i]);
                        if (!list.contains(solutionSet)) {
                            list.add(solutionSet);
                        }
                    }
                }
            }
        }

        for (List<Integer> item : list) {
            for (int i : item) {
                printtln(i);
            }
            printtln("---");
        }
        return list;
    }

    public static int[] twoSum(int[] nums, int target) {
        HashMap<Integer,Integer> numMap = new HashMap<>();

        for (int i = 0; i < nums.length ; ++i) {
            if (numMap.containsKey(target - nums[i]))  {
                return new int[] {numMap.get(target - nums[i]), i};
            }
            numMap.put(nums[i],i);

        }
        return null;
    }
    public static int threeSumClosest(int[] nums, int target) {
        if (nums.length == 0 ) return 0;
        if (nums.length == 3) {
            return nums[0] + nums[1] + nums[2];
        }

        Arrays.sort(nums);
        int closest = nums[0] + nums[1] + nums[2];
        printtln("close:" + closest);

        for (int i = 0; i < nums.length - 2; ++i) {
            int j = i + 1;
            int k = nums.length - 1;

            while (j < k) {
                int sum = nums[i] + nums[j] + nums[k];
//                printtln("sum: " + sum + " i: " + nums[i] + " j: " + nums[j] + " k: " + nums[k]);

                if (Math.abs(sum - target) < Math.abs(closest - target)) {
                    printtln("test");
                    closest = sum;
//                    ++j;
//                    --k;
                } else if (sum < target) {
                    ++j;
                } else {
                    --k;
                }
            }

        }
//        printtln(closest);
        return closest;
    }
    public ListNode removeNthFromEnd(ListNode head, int n) {
        if (head == null) return head;
        else if (n == 0) {
            return head;
        }

        ListNode p1 = head;
        ListNode p2 = head;
        ListNode headCopy = head;
        ListNode previousP2 = null;
        int count = n;

        while (p1 != null) {
            p1 = p1.next;
            --count;
            if (count < 0) {
                previousP2 = p2;
                p2 = p2.next;
                if (p2 == null)
                    break;
            }
        }

        if (p2 == head) {
            if (p2.next == null) {
                return null;
            } else {
                headCopy = p2.next;
            }
        } else {
            previousP2.next = p2.next;
        }
       return headCopy;
    }
    public static boolean isValid(String s) {
        if (s.length() % 2 != 0) {
            return false;
        } else if (s.length() == 0) {
            return true;
        }

        Stack<Character> open = new Stack<>();

        for (int i = 0; i < s.length(); ++ i) {
            if (s.charAt(i) == '(' || s.charAt(i) == '{' || s.charAt(i) == '[' ) {
                open.push(s.charAt(i));
            } else if (open.size() != 0) {
                char openChar = open.pop();
                if (openChar == '(' && s.charAt(i) != ')') {
                    return false;
                } else if (openChar == '{' && s.charAt(i) != '}') {
                    return false;
                } else if (openChar == '[' && s.charAt(i) != ']') {
                    return false;
                }
            } else
                return false;
        }
        return open.isEmpty();
    }

    public ListNode addTwoNumbers(ListNode l1, ListNode l2) {
        ListNode ans = new ListNode(0);
        ListNode headAnswer = ans;
        int carry = 0;
        int sum;
        while (true) {
            sum = 0;
            if (l1 != null && l2 != null) {
                sum = l1.val + l2.val + carry;
                if (sum > 9) {
                    carry = sum / 10;
                    sum = sum - 10;
                } else {
                    carry = 0;
                }
            }
            ans.val = sum;

            l1 = l1.next;
            l2 = l2.next;

            if (l1 == null || l2 == null) {
                break;
            }
            ans.next = new ListNode(0);
            ans = ans.next;
        }

        while (l1 != null) {

            sum = l1.val;
            if (sum > 9) {
                carry = sum/10;
                sum = sum - 10;
            } else {
                carry = 0;
            }
            ans.next = new ListNode(sum + carry);
            ans = ans.next;

            l1 = l1.next;
        }

        while (l2 != null) {
            sum = l2.val;
            if (sum > 9) {
                carry = sum/10;
                sum = sum - 10;
            } else {
                carry = 0;
            }
            ans.next = new ListNode(sum + carry);
            ans = ans.next;

            l2 = l2.next;
        }
        return headAnswer;
    }

    public static List<List<String>> groupAnagrams(String[] strs) {
        HashMap<Integer, LinkedList<String>> map = new HashMap<>();
        for(String s : strs) {
            int[] freq = new int[26];
            for(int i = 0; i < s.length(); i++) {
                freq[s.charAt(i) - 'a']++; // change to a 1 if the letter exists in the string
            }
            int key = Arrays.hashCode(freq);
            if(!map.containsKey(key)) map.put(key, new LinkedList<>());
            map.get(key).add(s);
        }
        return new ArrayList<>(map.values());
    }


    public  ListNode mergeKLists(ListNode[] lists) {
        if (lists.length == 0) return null;
        ListNode resultHead = new ListNode(0);
        ListNode result = resultHead;

        quickSort(lists, 0, lists.length - 1);

        int nullCount = 0;
        while (nullCount < lists.length) {
            for (int i = 0; i < lists.length; ++i) {
                result.next = new ListNode(lists[i].val);
                result = result.next;
                if (lists[i].next == null) {
                    ++nullCount;
                } else {
                    lists[i] = lists[i].next;
                }
            }
            quickSort(lists, 0, lists.length - 1 - nullCount);
        }

        resultHead = resultHead.next;

        return resultHead;
    }

    private void quickSort(ListNode[] list, int left, int right) {
        if (left < right) {
            int p = partition(list, left, right);

            quickSort(list, left, p - 1);
            quickSort(list, p + 1, right);
        }
    }

    private int partition(ListNode[] list, int left, int right) {
        int p = list[right].val;
        int i = left - 1;

        for (int k = left; k < right; ++k) {
            if (list[k].val <= p) {
                ++i;

                int temp = list[k].val;
                list[k].val = list[i].val;
                list[i].val = temp;
            }
        }

        int temp = list[right].val;
        list[right].val = list[i + 1].val;
        list[i + 1].val = temp;

        return i + 1;
    }
}